import React from 'react';
import { useState } from 'react';
import { useSelector,useDispatch } from 'react-redux';
import {AddTodo} from '../actions/index';

function Todo(props) {
    const [inputData,setInputData] = useState('');
    const list = useSelector((state)=>state.listdata.list);
    const dispatch = useDispatch();

    return (
        <div className="container">
            <div className="row">
                <h1>ToDo Application </h1>
                <div className="col-3">
                    <input type="text" className='form-control' value={inputData} onChange={(event)=>{setInputData(event.target.value)}}/>
                </div>
                <div className="col-3">
                    <button className='btn btn-primary' onClick={()=>{dispatch(AddTodo(inputData),setInputData(''))}}>ADD TASK</button>
                </div>
            </div>
        </div>
    );
}

export default Todo;