import React from 'react';

function Home(props) {
    return (
        <>
         <div className='container-fiuid main-container bg-dark'>
            <p className='home1 text-white'>Hey, My name is</p>
            <p className='home2 text-white'>Digal Patel</p>
            <p className='home3 text-white'>I'm web developer.</p>

            <button className='btn btn-primary mt-5 btn1'>Hire me</button>
         </div>
        </>
    );
}

export default Home;



