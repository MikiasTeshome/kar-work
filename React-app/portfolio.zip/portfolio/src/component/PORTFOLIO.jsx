import React from 'react';

function PORTFOLIO(props) {
    return (
        <>
        <div className='main2 bg-dark'>
        <div className='container portfolio bg-dark text-white'>
           <center> <h1 className='p-5'>PORTFOLIO</h1></center>
            <p className='portfolio1'>Project I have done</p>
            <div className='port'>       
            <div className='port1'>

            </div>
            <div className='port1'>

            </div>
            <div className='port1'>
                
            </div>
            </div>
        </div>
        </div>
        </>
    );
}

export default PORTFOLIO;