import React from 'react';

function ACHIEVEMENT(props) {
    return (
       <>
       <div className='main3 bg-dark'>
        <div className='container achievement bg-dark text-white'>
            <center><h1 className='p-5'>ACHIEVEMENT</h1></center>
           
            <div className='achieve'>       
            <div className='achieve1'></div>
            <div className='achieve1'></div>
            <div className='achieve1'></div>
            </div>
        </div>
        </div>
       </>
    );
}

export default ACHIEVEMENT;