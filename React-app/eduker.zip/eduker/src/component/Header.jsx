import React from 'react';
import Home from './Home';

function Header(props) {
    return (
        <div>
           
        </div>
    );
}

export default Header;